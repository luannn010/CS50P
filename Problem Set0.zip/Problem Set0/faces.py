#define main function
def main():
#execute convert function
 convert()
#define convert function
def convert():

 x = input()
 x = x.replace(":(","🙁")
 x = x.replace(":)","🙂")
 print(x)

 return
#execute main
main()
