x = input("Enter a sentence: ")
print("Output: " + x.lower())