x = input("Enter the input: ")
#Use replace function
print(x.replace(" ","..."))
